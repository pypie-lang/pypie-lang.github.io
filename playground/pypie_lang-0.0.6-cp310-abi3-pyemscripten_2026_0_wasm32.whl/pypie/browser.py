"""PyPie in the browser (Pyodide).

This module is the Python half of the playground runtime contract:

- ``run_source`` executes playground source in a fresh module namespace, the
  way the playground worker runs the editor buffer.
- ``call_tfjs`` is called by the compiler's TFJS backend to execute a compiled
  program. It forwards the program and its runtime inputs to the
  ``__pypieRunTfjsSync`` function that the playground worker installs on the
  JavaScript global scope, then rebuilds Python values from the result.

Everything here must stay importable outside Pyodide (the ``js`` and
``pyodide.ffi`` imports are deferred into ``call_tfjs``) so the module can be
exercised by native tests.
"""

import linecache
import os
import types

import numpy as np

PLAYGROUND_FILENAME = "/tmp/pypie-playground/playground.py"


def run_source(source, filename=PLAYGROUND_FILENAME):
    """Execute ``source`` as a fresh ``__main__``-style module.

    The source is written to ``filename`` and registered in ``linecache`` so
    the PyPie parser and traceback rendering can recover it.
    """
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, "w", encoding="utf-8") as file:
        file.write(source)
    linecache.cache[filename] = (
        len(source),
        None,
        source.splitlines(True),
        filename,
    )
    module = types.ModuleType("__pypie_playground__")
    module_globals = module.__dict__
    module_globals["__name__"] = "__main__"
    module_globals["__package__"] = ""
    module_globals["__file__"] = filename
    exec(compile(source, filename, "exec"), module_globals, module_globals)


def call_tfjs(program, inputs):
    """Run a compiled TFJS program through the playground's JS runtime."""
    import js
    from pyodide.ffi import to_js

    payload = {
        "runtimeSource": program["runtimeSource"],
        "resultType": program["resultType"],
        "inputs": [
            {
                "name": item["name"],
                "schema": item["schema"],
                "value": _plain(item["value"]),
            }
            for item in inputs
        ],
    }
    js_payload = to_js(payload, dict_converter=js.Object.fromEntries)
    result = js.__pypieRunTfjsSync(js_payload)
    return _from_tfjs(result, program["resultType"])


def _plain(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    if isinstance(value, tuple):
        return [_plain(item) for item in value]
    if isinstance(value, list):
        return [_plain(item) for item in value]
    if isinstance(value, dict):
        return {key: _plain(item) for key, item in value.items()}
    return value


def _np_dtype(name):
    if name == "float32":
        return np.float32
    if name == "int32":
        return np.int32
    if name == "bool":
        return np.bool_
    if name == "string":
        return np.str_
    return None


def _from_tfjs(value, schema):
    if hasattr(value, "to_py"):
        value = value.to_py()
    kind = schema.get("kind")
    if isinstance(value, dict) and value.get("__pypieTensor"):
        array = np.asarray(value.get("value"), dtype=_np_dtype(value.get("dtype")))
        if kind == "scalar":
            return array.item()
        return array
    if kind == "tuple":
        elems = schema.get("elems", [])
        if len(value) != len(elems):
            raise TypeError(
                f"TFJS returned tuple with {len(value)} elements, expected {len(elems)}"
            )
        return tuple(
            _from_tfjs(item, item_schema) for item, item_schema in zip(value, elems)
        )
    if kind == "list":
        return [_from_tfjs(item, schema.get("elem", {"kind": "value"})) for item in value]
    if kind == "record":
        fields = schema.get("fields", {})
        missing = [key for key in fields if key not in value]
        if missing:
            raise TypeError(
                f"TFJS returned record missing field(s): {', '.join(missing)}"
            )
        return {
            key: _from_tfjs(value[key], fields.get(key, {"kind": "value"}))
            for key in value
        }
    return value
